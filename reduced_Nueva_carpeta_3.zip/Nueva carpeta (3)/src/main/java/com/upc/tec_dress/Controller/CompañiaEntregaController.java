package com.upc.tec_dress.Controller;

import com.upc.tec_dress.Services.CompañiaEntregaService;
import com.upc.tec_dress.dtos.CompaniaEntregaDTO;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/compa")
public class CompañiaEntregaController {
    private final CompañiaEntregaService compañiaEntregaService;

    @Autowired
    public CompañiaEntregaController(CompañiaEntregaService compañiaEntregaService) {
        this.compañiaEntregaService = compañiaEntregaService;
    }

    @PostMapping
    public ResponseEntity<CompaniaEntregaDTO> saveCompaniaEntrega(@Valid @RequestBody CompaniaEntregaDTO companiaEntregaDTO) {
        CompaniaEntregaDTO savedCompaniaEntrega = compañiaEntregaService.save(companiaEntregaDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedCompaniaEntrega);
    }

    @GetMapping
    public ResponseEntity<List<CompaniaEntregaDTO>> getCompaniasEntrega() {
        List<CompaniaEntregaDTO> companiasEntrega = compañiaEntregaService.list();
        return ResponseEntity.ok(companiasEntrega);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CompaniaEntregaDTO> getCompaniaEntregaById(@PathVariable Integer id) {
        CompaniaEntregaDTO companiaEntregaDTO = compañiaEntregaService.findById(id);
        return ResponseEntity.ok(companiaEntregaDTO);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCompaniaEntrega(@PathVariable Integer id) {
        compañiaEntregaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
