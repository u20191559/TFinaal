package com.upc.tec_dress.Controller;

import com.upc.tec_dress.Services.MetodoPagoService;
import com.upc.tec_dress.dtos.MetodoPagoDTO;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/meto")
public class MetodoPagoController {
    private final MetodoPagoService metodoPagoService;

    @Autowired
    public MetodoPagoController(MetodoPagoService metodoPagoService) {
        this.metodoPagoService = metodoPagoService;
    }

    @PostMapping
    public ResponseEntity<MetodoPagoDTO> saveMetodoPago(@Valid @RequestBody MetodoPagoDTO metodoPagoDTO) {
        MetodoPagoDTO savedMetodoPago = metodoPagoService.save(metodoPagoDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedMetodoPago);
    }

    @GetMapping
    public ResponseEntity<List<MetodoPagoDTO>> getMetodosPago() {
        List<MetodoPagoDTO> metodosPago = metodoPagoService.list();
        return ResponseEntity.ok(metodosPago);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MetodoPagoDTO> getMetodoPagoById(@PathVariable Integer id) {
        MetodoPagoDTO metodoPagoDTO = metodoPagoService.findById(id);
        return ResponseEntity.ok(metodoPagoDTO);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMetodoPago(@PathVariable Integer id) {
        metodoPagoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
