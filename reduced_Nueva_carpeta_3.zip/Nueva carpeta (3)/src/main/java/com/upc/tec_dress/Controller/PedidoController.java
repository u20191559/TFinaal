package com.upc.tec_dress.Controller;

import com.upc.tec_dress.Services.PedidoService;
import com.upc.tec_dress.dtos.PedidoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/pedi")
public class PedidoController {
    private final PedidoService pedidoService;

    @Autowired
    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @PostMapping
    public ResponseEntity<PedidoDTO> savePedido(@Valid @RequestBody PedidoDTO pedidoDTO) {
        PedidoDTO savedPedido = pedidoService.save(pedidoDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedPedido);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PedidoDTO> buscarPedido(@PathVariable Long id) {
        try {
            PedidoDTO pedido = pedidoService.buscar(id);
            return ResponseEntity.ok(pedido);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<PedidoDTO>> getPedidos() {
        List<PedidoDTO> pedidos = pedidoService.list();
        return ResponseEntity.ok(pedidos);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PedidoDTO> updatePedido(@PathVariable int id, @Valid @RequestBody PedidoDTO pedidoDTO) {
        try {
            PedidoDTO updatedPedido = pedidoService.update(id, pedidoDTO);
            return ResponseEntity.ok(updatedPedido);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<PedidoDTO> borrarPedido(@PathVariable Long id) {
        try {
            PedidoDTO deletedPedido = pedidoService.borrarPedido(id);
            return ResponseEntity.ok(deletedPedido);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/balance-ganancias")
    public ResponseEntity<Double> getBalanceGanancias() {
        Double balance = pedidoService.getBalanceGanancias();
        return ResponseEntity.ok(balance);
    }
}
