package com.upc.tec_dress.Controller;

import com.upc.tec_dress.Services.PrendaService;
import com.upc.tec_dress.dtos.PrendaDTO;
import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/prenda")
public class PrendaController {
    private final PrendaService prendaService;

    @Autowired
    public PrendaController(PrendaService prendaService) {
        this.prendaService = prendaService;
    }

    @PostMapping
    public ResponseEntity<PrendaDTO> savePrenda(@Valid @RequestBody PrendaDTO prendaDTO) {
        PrendaDTO savedPrenda = prendaService.save(prendaDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedPrenda);
    }

    @GetMapping
    public ResponseEntity<List<PrendaDTO>> getPrendas() {
        List<PrendaDTO> prendas = prendaService.list();
        return ResponseEntity.ok(prendas);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PrendaDTO> updatePrenda(@PathVariable int id, @Valid @RequestBody PrendaDTO prendaDTO) {
        PrendaDTO updatedPrenda = prendaService.update(id, prendaDTO);
        return ResponseEntity.ok(updatedPrenda);
    }

    @PutMapping("/{prendaId}/precio")
    public ResponseEntity<PrendaDTO> updatePrecio(@PathVariable int prendaId, @RequestParam double nuevoPrecio) {
        PrendaDTO updatedPrenda = prendaService.updatePrecio(prendaId, nuevoPrecio);
        if (updatedPrenda != null) {
            return ResponseEntity.ok(updatedPrenda);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/nombreCantidad")
    public Map<String, Integer> getNombreCantidadPrendas() {
        return prendaService.getNombreCantidadPrendas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PrendaDTO> getPrendaById(@PathVariable int id) {
        try {
            PrendaDTO prendaDTO = prendaService.findById(id);
            return ResponseEntity.ok(prendaDTO);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}
