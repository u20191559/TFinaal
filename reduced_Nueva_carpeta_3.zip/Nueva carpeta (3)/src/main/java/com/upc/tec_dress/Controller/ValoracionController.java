package com.upc.tec_dress.Controller;

import com.upc.tec_dress.Services.ValoracionService;
import com.upc.tec_dress.dtos.ValoracionDTO;
import com.upc.tec_dress.entities.Valoracion;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/valo")
public class ValoracionController {
    private final ValoracionService valoracionService;

    @Autowired
    public ValoracionController(ValoracionService valoracionService) {
        this.valoracionService = valoracionService;
    }

    @PostMapping("/pedido")
    public ResponseEntity<ValoracionDTO> savePedidoValoracion(@Valid @RequestBody ValoracionDTO valoracionDTO) {
        ValoracionDTO savedValoracion = valoracionService.savePedidoValoracion(valoracionDTO);
        return new ResponseEntity<>(savedValoracion, HttpStatus.CREATED);
    }

    @PostMapping("/prenda")
    public ResponseEntity<ValoracionDTO> savePrendaValoracion(@Valid @RequestBody ValoracionDTO valoracionDTO) {
        ValoracionDTO savedValoracion = valoracionService.savePrendaValoracion(valoracionDTO);
        return new ResponseEntity<>(savedValoracion, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<ValoracionDTO>> getValoraciones() {
        List<ValoracionDTO> valoraciones = valoracionService.list();
        return ResponseEntity.ok(valoraciones);
    }

    @GetMapping("/producto-vendido/{productoVendidoId}")
    public ResponseEntity<List<ValoracionDTO>> getValoracionesByProductoVendidoId(@PathVariable int productoVendidoId) {
        List<ValoracionDTO> valoraciones = valoracionService.findByProductoVendidoId(productoVendidoId);
        return ResponseEntity.ok(valoraciones);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ValoracionDTO> getValoracionById(@PathVariable int id) {
        try {
            ValoracionDTO valoracionDTO = valoracionService.findById(id);
            return ResponseEntity.ok(valoracionDTO);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}
