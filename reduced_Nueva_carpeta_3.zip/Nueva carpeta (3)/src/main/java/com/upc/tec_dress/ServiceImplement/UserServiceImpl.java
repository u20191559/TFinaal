package com.upc.tec_dress.ServiceImplement;

import com.upc.tec_dress.Services.UserService;
import com.upc.tec_dress.dtos.DTOUser;
import com.upc.tec_dress.entities.AuthorityName;
import com.upc.tec_dress.entities.User;
import com.upc.tec_dress.exceptions.IncompleteDataException;
import com.upc.tec_dress.exceptions.KeyRepeatedDataException;
import com.upc.tec_dress.exceptions.ResourceNotFoundException;
import com.upc.tec_dress.repository.AuthorityRepository;
import com.upc.tec_dress.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    UserRepository userRepository;
    @Autowired
    AuthorityRepository authorityRepository;

    @Override
    public User findById(Long id) {
        User userFound = userRepository.findById(id).orElse(null);
        if (userFound == null) {
            throw new ResourceNotFoundException("There are no User with the id: " + id);
        }
        return userFound;
    }

    @Override
    public User register(DTOUser user) {
        if (user.getUserName().length() > 4 && user.getPassword().length() > 4) {

            User userFound = userRepository.findByUserName(user.getUserName());
            if (userFound != null) {
                throw new KeyRepeatedDataException("User name can not be duplicated");
            }

            User newUser = new User();
            newUser.setUserName(user.getUserName());
            newUser.setFirstName(user.getFirstName());
            newUser.setLastName(user.getLastName());
            newUser.setBirthdate(user.getBirthdate());
            newUser.setGenero(user.getGenero());
            newUser.setEmail(user.getEmail());
            newUser.setDireccion(user.getDireccion());
            newUser.setTalla(user.getTalla());

            newUser.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
            newUser.setEnabled(true);
            AuthorityName authorityName = AuthorityName.ROLE_CLIENTE;
            if (user.getType().equals("ROLE_CLIENTE")) authorityName = AuthorityName.ROLE_CLIENTE;
            if (user.getType().equals("ROLE_ADMIN")) authorityName = AuthorityName.ROLE_ADMIN;
            newUser.setAuthorities(
                    List.of(
                            authorityRepository.findByName(authorityName)
                    )
            );

            return userRepository.save(newUser);
        } else {
            throw new IncompleteDataException("User name and password length can not be less than 4 characters");
        }
    }

    @Override
    public User changePassword(DTOUser user) {
        if (user.getUserName().length() > 4 && user.getPassword().length() > 4) {

            User userFound = userRepository.findByUserName(user.getUserName());
            if (userFound == null) {
                throw new ResourceNotFoundException("User name can not be found");
            }

            userFound.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
            return userRepository.save(userFound);
        } else {
            throw new IncompleteDataException("User name and password length can not be less than 4 characters");
        }
    }

    @Override
    public List<User> list() {
        return userRepository.findAll();
    }
}
