package com.upc.tec_dress.Services;

import com.upc.tec_dress.entities.Authority;

public interface AuthorityService {
    public Authority save(Authority authority);
}
