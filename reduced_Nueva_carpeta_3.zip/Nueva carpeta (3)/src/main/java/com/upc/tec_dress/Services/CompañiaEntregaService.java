package com.upc.tec_dress.Services;

import com.upc.tec_dress.dtos.CompaniaEntregaDTO;
import com.upc.tec_dress.entities.CompaniaEntrega;
import com.upc.tec_dress.repository.CompañiaEntregaRepository;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CompañiaEntregaService {
    @Autowired
    private CompañiaEntregaRepository companiaEntregaRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Transactional
    public CompaniaEntregaDTO save(CompaniaEntregaDTO companiaEntregaDTO) {
        CompaniaEntrega companiaEntrega = modelMapper.map(companiaEntregaDTO, CompaniaEntrega.class);
        CompaniaEntrega savedCompaniaEntrega = companiaEntregaRepository.save(companiaEntrega);
        return modelMapper.map(savedCompaniaEntrega, CompaniaEntregaDTO.class);
    }

    public List<CompaniaEntregaDTO> list() {
        List<CompaniaEntrega> companiasEntrega = companiaEntregaRepository.findAll();
        return companiasEntrega.stream()
                .map(companiaEntrega -> modelMapper.map(companiaEntrega, CompaniaEntregaDTO.class))
                .collect(Collectors.toList());
    }

    public CompaniaEntregaDTO findById(Integer id) {
        Optional<CompaniaEntrega> optionalCompaniaEntrega = companiaEntregaRepository.findById(id);
        if (optionalCompaniaEntrega.isPresent()) {
            return modelMapper.map(optionalCompaniaEntrega.get(), CompaniaEntregaDTO.class);
        } else {
            throw new EntityNotFoundException("CompaniaEntrega not found with id: " + id);
        }
    }

    @Transactional
    public void delete(Integer id) {
        companiaEntregaRepository.deleteById(id);
    }
}
