package com.upc.tec_dress.Services;

import com.upc.tec_dress.dtos.MetodoPagoDTO;
import com.upc.tec_dress.entities.MetodoPago;
import com.upc.tec_dress.repository.MetodoPagoRepository;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MetodoPagoService {
    private final MetodoPagoRepository metodoPagoRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public MetodoPagoService(MetodoPagoRepository metodoPagoRepository, ModelMapper modelMapper) {
        this.metodoPagoRepository = metodoPagoRepository;
        this.modelMapper = modelMapper;
    }

    @Transactional
    public MetodoPagoDTO save(MetodoPagoDTO metodoPagoDTO) {
        MetodoPago metodoPago = modelMapper.map(metodoPagoDTO, MetodoPago.class);
        MetodoPago savedMetodoPago = metodoPagoRepository.save(metodoPago);
        return modelMapper.map(savedMetodoPago, MetodoPagoDTO.class);
    }

    public List<MetodoPagoDTO> list() {
        List<MetodoPago> metodosPago = metodoPagoRepository.findAll();
        return metodosPago.stream()
                .map(metodoPago -> modelMapper.map(metodoPago, MetodoPagoDTO.class))
                .collect(Collectors.toList());
    }

    public MetodoPagoDTO findById(Integer id) {
        Optional<MetodoPago> optionalMetodoPago = metodoPagoRepository.findById(id);
        if (optionalMetodoPago.isPresent()) {
            return modelMapper.map(optionalMetodoPago.get(), MetodoPagoDTO.class);
        } else {
            throw new EntityNotFoundException("MetodoPago not found with id: " + id);
        }
    }

    @Transactional
    public void delete(Integer id) {
        metodoPagoRepository.deleteById(id);
    }
}
