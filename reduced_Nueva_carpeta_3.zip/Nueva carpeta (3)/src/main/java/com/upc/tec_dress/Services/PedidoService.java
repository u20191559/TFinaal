package com.upc.tec_dress.Services;

import com.upc.tec_dress.dtos.PedidoDTO;
import com.upc.tec_dress.entities.CompaniaEntrega;
import com.upc.tec_dress.entities.MetodoPago;
import com.upc.tec_dress.entities.Pedido;
import com.upc.tec_dress.entities.User;
import com.upc.tec_dress.repository.CompañiaEntregaRepository;
import com.upc.tec_dress.repository.MetodoPagoRepository;
import com.upc.tec_dress.repository.PedidoRepository;
import com.upc.tec_dress.repository.UserRepository;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PedidoService {
    private final PedidoRepository pedidoRepository;
    private final UserRepository userRepository;
    private final CompañiaEntregaRepository companiaEntregaRepository;
    private final MetodoPagoRepository metodoPagoRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public PedidoService(PedidoRepository pedidoRepository, UserRepository userRepository,
                         CompañiaEntregaRepository companiaEntregaRepository, MetodoPagoRepository metodoPagoRepository,
                         ModelMapper modelMapper) {
        this.pedidoRepository = pedidoRepository;
        this.userRepository = userRepository;
        this.companiaEntregaRepository = companiaEntregaRepository;
        this.metodoPagoRepository = metodoPagoRepository;
        this.modelMapper = modelMapper;
    }

    @Transactional
    public PedidoDTO save(PedidoDTO pedidoDTO) {
        if (pedidoDTO.getUserId() == null) {
            throw new IllegalArgumentException("El ID del cliente es requerido");
        }
        if (pedidoDTO.getCompaniaEntregaId() == null) {
            throw new IllegalArgumentException("El ID de la compañía de entrega es requerido");
        }
        if (pedidoDTO.getMetodoPagoId() == null) {
            throw new IllegalArgumentException("El ID del método de pago es requerido");
        }

        Pedido pedido = new Pedido();
        pedido.setCantidadPedido(pedidoDTO.getCantidadPedido());
        pedido.setFPedido(pedidoDTO.getFPedido());
        pedido.setFEntrega(pedidoDTO.getFEntrega());
        pedido.setStatus(pedidoDTO.getStatus());
        pedido.setPrecioTotal(pedidoDTO.getPrecioTotal());

        User user = userRepository.findById(pedidoDTO.getUserId())
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado"));
        pedido.setUsers(user);

        CompaniaEntrega companiaEntrega = companiaEntregaRepository.findById(pedidoDTO.getCompaniaEntregaId())
                .orElseThrow(() -> new IllegalArgumentException("Compañía de entrega no encontrada"));
        pedido.setCompaniaEntrega(companiaEntrega);

        MetodoPago metodoPago = metodoPagoRepository.findById(pedidoDTO.getMetodoPagoId())
                .orElseThrow(() -> new IllegalArgumentException("Método de pago no encontrado"));
        pedido.setMetodoPago(metodoPago);

        Pedido savedPedido = pedidoRepository.save(pedido);

        PedidoDTO savedPedidoDTO = new PedidoDTO();
        savedPedidoDTO.setId(savedPedido.getId());
        savedPedidoDTO.setCantidadPedido(savedPedido.getCantidadPedido());
        savedPedidoDTO.setFPedido(savedPedido.getFPedido());
        savedPedidoDTO.setFEntrega(savedPedido.getFEntrega());
        savedPedidoDTO.setStatus(savedPedido.getStatus());
        savedPedidoDTO.setPrecioTotal(savedPedido.getPrecioTotal());
        savedPedidoDTO.setUserId(savedPedido.getUsers().getId());
        savedPedidoDTO.setCompaniaEntregaId(savedPedido.getCompaniaEntrega().getIdCompaniaEntrega());
        savedPedidoDTO.setMetodoPagoId(savedPedido.getMetodoPago().getId());

        return savedPedidoDTO;
    }

    public PedidoDTO buscar(Long id) throws Exception {
        Optional<Pedido> optionalPedido = pedidoRepository.findById(Math.toIntExact(id));
        if (optionalPedido.isPresent()) {
            Pedido pedido = optionalPedido.get();
            PedidoDTO dto = new PedidoDTO();
            dto.setId(pedido.getId());
            dto.setCantidadPedido(pedido.getCantidadPedido());
            dto.setFPedido(pedido.getFPedido());
            dto.setFEntrega(pedido.getFEntrega());
            dto.setStatus(pedido.getStatus());
            dto.setPrecioTotal(pedido.getPrecioTotal());
            if (pedido.getUsers() != null) {
                dto.setUserId(pedido.getUsers().getId());
            }
            if (pedido.getCompaniaEntrega() != null) {
                dto.setCompaniaEntregaId(pedido.getCompaniaEntrega().getIdCompaniaEntrega());
            }
            if (pedido.getMetodoPago() != null) {
                dto.setMetodoPagoId(pedido.getMetodoPago().getId());
            }
            return dto;
        } else {
            throw new Exception("No se encontró el pedido");
        }
    }

    public List<PedidoDTO> list() {
        List<Pedido> pedidos = pedidoRepository.findAll();
        return pedidos.stream()
                .map(pedido -> {
                    PedidoDTO dto = new PedidoDTO();
                    dto.setId(pedido.getId());
                    dto.setCantidadPedido(pedido.getCantidadPedido());
                    dto.setFPedido(pedido.getFPedido());
                    dto.setFEntrega(pedido.getFEntrega());
                    dto.setStatus(pedido.getStatus());
                    dto.setPrecioTotal(pedido.getPrecioTotal());
                    if (pedido.getUsers() != null) {
                        dto.setUserId(pedido.getUsers().getId());
                    }
                    if (pedido.getCompaniaEntrega() != null) {
                        dto.setCompaniaEntregaId(pedido.getCompaniaEntrega().getIdCompaniaEntrega());
                    }
                    if (pedido.getMetodoPago() != null) {
                        dto.setMetodoPagoId(pedido.getMetodoPago().getId());
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Transactional
    public PedidoDTO update(int pedidoId, PedidoDTO pedidoDTO) {
        Pedido pedido = pedidoRepository.findById(pedidoId).orElseThrow(() -> new EntityNotFoundException("Pedido not found"));

        pedido.setCantidadPedido(pedidoDTO.getCantidadPedido());
        pedido.setFPedido(pedidoDTO.getFPedido());
        pedido.setFEntrega(pedidoDTO.getFEntrega());
        pedido.setStatus(pedidoDTO.getStatus());
        pedido.setPrecioTotal(pedidoDTO.getPrecioTotal());

        User user = userRepository.findById(pedidoDTO.getUserId())
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado"));
        pedido.setUsers(user);

        CompaniaEntrega companiaEntrega = companiaEntregaRepository.findById(pedidoDTO.getCompaniaEntregaId())
                .orElseThrow(() -> new IllegalArgumentException("Compañía de entrega no encontrada"));
        pedido.setCompaniaEntrega(companiaEntrega);

        MetodoPago metodoPago = metodoPagoRepository.findById(pedidoDTO.getMetodoPagoId())
                .orElseThrow(() -> new IllegalArgumentException("Método de pago no encontrado"));
        pedido.setMetodoPago(metodoPago);

        Pedido updatedPedido = pedidoRepository.save(pedido);
        return modelMapper.map(updatedPedido, PedidoDTO.class);
    }

    @Transactional
    public PedidoDTO borrarPedido(Long id) throws Exception {
        Optional<Pedido> optionalPedido = pedidoRepository.findById(Math.toIntExact(id));
        if (optionalPedido.isPresent()) {
            Pedido pedido = optionalPedido.get();
            pedidoRepository.delete(pedido);
            return modelMapper.map(pedido, PedidoDTO.class);
        } else {
            throw new Exception("No se encontró el pedido");
        }
    }

    public Double getBalanceGanancias() {
        return pedidoRepository.getBalanceGanancias();
    }
}
