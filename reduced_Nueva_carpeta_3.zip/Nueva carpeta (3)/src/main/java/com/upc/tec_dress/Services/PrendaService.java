package com.upc.tec_dress.Services;

import com.upc.tec_dress.dtos.PrendaDTO;
import com.upc.tec_dress.entities.Prenda;
import com.upc.tec_dress.repository.PrendaRepository;
import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PrendaService {
    private final PrendaRepository prendaRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public PrendaService(PrendaRepository prendaRepository, ModelMapper modelMapper) {
        this.prendaRepository = prendaRepository;
        this.modelMapper = modelMapper;
    }

    @Transactional
    public PrendaDTO save(PrendaDTO prendaDTO) {
        Prenda prenda = modelMapper.map(prendaDTO, Prenda.class);
        Prenda savedPrenda = prendaRepository.save(prenda);
        return modelMapper.map(savedPrenda, PrendaDTO.class);
    }

    public List<PrendaDTO> list() {
        List<Prenda> prendas = prendaRepository.findAll();
        return prendas.stream()
                .map(prenda -> modelMapper.map(prenda, PrendaDTO.class))
                .collect(Collectors.toList());
    }

    @Transactional
    public PrendaDTO update(int prendaId, PrendaDTO prendaDTO) {
        Prenda prenda = prendaRepository.findById(prendaId).orElseThrow(() -> new EntityNotFoundException("Prenda not found"));
        modelMapper.map(prendaDTO, prenda);
        Prenda updatedPrenda = prendaRepository.save(prenda);
        return modelMapper.map(updatedPrenda, PrendaDTO.class);
    }

    public Map<String, Integer> getNombreCantidadPrendas() {
        List<Object[]> results = prendaRepository.getNombreCantidadPrendas();
        Map<String, Integer> nombreCantidadMap = new HashMap<>();

        for (Object[] result : results) {
            String nombre = (String) result[0];
            Integer cantidad = ((Number) result[1]).intValue();
            nombreCantidadMap.put(nombre, cantidad);
        }

        return nombreCantidadMap;
    }

    public PrendaDTO updatePrecio(int prendaId, double nuevoPrecio) {
        Optional<Prenda> optionalPrenda = prendaRepository.findById(prendaId);
        if (optionalPrenda.isPresent()) {
            Prenda prenda = optionalPrenda.get();
            prenda.setPrecio(nuevoPrecio);
            Prenda prendaActualizada = prendaRepository.save(prenda);
            return modelMapper.map(prendaActualizada, PrendaDTO.class);
        }
        return null;
    }

    public PrendaDTO findById(int prendaId) {
        Optional<Prenda> optionalPrenda = prendaRepository.findById(prendaId);
        if (optionalPrenda.isPresent()) {
            return modelMapper.map(optionalPrenda.get(), PrendaDTO.class);
        } else {
            throw new EntityNotFoundException("Prenda not found with id: " + prendaId);
        }
    }
}
