package com.upc.tec_dress.Services;



import com.upc.tec_dress.dtos.DTOUser;
import com.upc.tec_dress.entities.User;

import java.util.List;

public interface UserService {

    public User findById(Long id);

    public User register(DTOUser user);

    public User changePassword(DTOUser user);

    public List<User> list();

}
