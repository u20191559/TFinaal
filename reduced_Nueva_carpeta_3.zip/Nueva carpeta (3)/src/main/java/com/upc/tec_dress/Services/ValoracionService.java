package com.upc.tec_dress.Services;

import com.upc.tec_dress.dtos.ValoracionDTO;
import com.upc.tec_dress.entities.Pedido;
import com.upc.tec_dress.entities.Prenda;
import com.upc.tec_dress.entities.User;
import com.upc.tec_dress.entities.Valoracion;
import com.upc.tec_dress.repository.PedidoRepository;
import com.upc.tec_dress.repository.PrendaRepository;
import com.upc.tec_dress.repository.UserRepository;
import com.upc.tec_dress.repository.ValoracionRepository;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ValoracionService {
    private final ValoracionRepository valoracionRepository;
    private final PrendaRepository prendaRepository;
    private final PedidoRepository pedidoRepository;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public ValoracionService(ValoracionRepository valoracionRepository, PrendaRepository prendaRepository, PedidoRepository pedidoRepository, UserRepository userRepository, ModelMapper modelMapper) {
        this.valoracionRepository = valoracionRepository;
        this.pedidoRepository = pedidoRepository;
        this.prendaRepository = prendaRepository;
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @Transactional
    public ValoracionDTO savePedidoValoracion(ValoracionDTO valoracionDTO) {
        if (valoracionDTO.getPedidoId() == null) {
            throw new IllegalArgumentException("El ID del pedido es requerido");
        }
        if (valoracionDTO.getUserId() == null) {
            throw new IllegalArgumentException("El ID del cliente es requerido");
        }

        Valoracion valoracion = new Valoracion();
        valoracion.setPuntuacionProducto(valoracionDTO.getPuntuacionProducto());
        valoracion.setComentario(valoracionDTO.getComentario());

        Pedido pedido = pedidoRepository.findById(valoracionDTO.getPedidoId())
                .orElseThrow(() -> new IllegalArgumentException("Pedido no encontrado"));
        valoracion.setPedido(pedido);

        User user = userRepository.findById(valoracionDTO.getUserId())
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado"));
        valoracion.setUsers(user);

        Valoracion savedValoracion = valoracionRepository.save(valoracion);

        ValoracionDTO savedValoracionDTO = new ValoracionDTO();
        savedValoracionDTO.setId(savedValoracion.getId());
        savedValoracionDTO.setPuntuacionProducto(savedValoracion.getPuntuacionProducto());
        savedValoracionDTO.setComentario(savedValoracion.getComentario());
        savedValoracionDTO.setUserId(savedValoracion.getUsers().getId());
        savedValoracionDTO.setPedidoId(savedValoracion.getPedido().getId());
        if (savedValoracion.getPrenda() != null) {
            savedValoracionDTO.setPrendaId(savedValoracion.getPrenda().getId());
        }

        return savedValoracionDTO;
    }

    @Transactional
    public ValoracionDTO savePrendaValoracion(ValoracionDTO valoracionDTO) {
        if (valoracionDTO.getPrendaId() == null) {
            throw new IllegalArgumentException("El ID de la prenda es requerido");
        }
        if (valoracionDTO.getUserId() == null) {
            throw new IllegalArgumentException("El ID del cliente es requerido");
        }

        Valoracion valoracion = new Valoracion();
        valoracion.setPuntuacionProducto(valoracionDTO.getPuntuacionProducto());
        valoracion.setComentario(valoracionDTO.getComentario());

        Prenda prenda = prendaRepository.findById(valoracionDTO.getPrendaId())
                .orElseThrow(() -> new IllegalArgumentException("Prenda no encontrada"));
        valoracion.setPrenda(prenda);

        User user = userRepository.findById(valoracionDTO.getUserId())
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado"));
        valoracion.setUsers(user);

        Valoracion savedValoracion = valoracionRepository.save(valoracion);

        ValoracionDTO savedValoracionDTO = new ValoracionDTO();
        savedValoracionDTO.setId(savedValoracion.getId());
        savedValoracionDTO.setPuntuacionProducto(savedValoracion.getPuntuacionProducto());
        savedValoracionDTO.setComentario(savedValoracion.getComentario());
        savedValoracionDTO.setUserId(savedValoracion.getUsers().getId());
        if (savedValoracion.getPedido() != null) {
            savedValoracionDTO.setPedidoId(savedValoracion.getPedido().getId());
        }
        savedValoracionDTO.setPrendaId(savedValoracion.getPrenda().getId());

        return savedValoracionDTO;
    }

    public List<ValoracionDTO> list() {
        List<Valoracion> valoraciones = valoracionRepository.findAll();
        return valoraciones.stream()
                .map(valoracion -> {
                    ValoracionDTO dto = new ValoracionDTO();
                    dto.setId(valoracion.getId());
                    dto.setPuntuacionProducto(valoracion.getPuntuacionProducto());
                    dto.setComentario(valoracion.getComentario());
                    if (valoracion.getUsers() != null) {
                        dto.setUserId(valoracion.getUsers().getId());
                    }
                    if (valoracion.getPedido() != null) {
                        dto.setPedidoId(valoracion.getPedido().getId());
                    }
                    if (valoracion.getPrenda() != null) {
                        dto.setPrendaId(valoracion.getPrenda().getId());
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }

    public List<ValoracionDTO> findByProductoVendidoId(int productoVendidoId) {
        List<Valoracion> valoraciones = valoracionRepository.findAllById(Collections.singleton(productoVendidoId));
        return valoraciones.stream()
                .map(valoracion -> {
                    ValoracionDTO dto = new ValoracionDTO();
                    dto.setId(valoracion.getId());
                    dto.setPuntuacionProducto(valoracion.getPuntuacionProducto());
                    dto.setComentario(valoracion.getComentario());
                    if (valoracion.getUsers() != null) {
                        dto.setUserId(valoracion.getUsers().getId());
                    }
                    if (valoracion.getPedido() != null) {
                        dto.setPedidoId(valoracion.getPedido().getId());
                    }
                    if (valoracion.getPrenda() != null) {
                        dto.setPrendaId(valoracion.getPrenda().getId());
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }

    public ValoracionDTO findById(Integer id) {
        Optional<Valoracion> optionalValoracion = valoracionRepository.findById(id);
        if (optionalValoracion.isPresent()) {
            Valoracion valoracion = optionalValoracion.get();
            ValoracionDTO dto = new ValoracionDTO();
            dto.setId(valoracion.getId());
            dto.setPuntuacionProducto(valoracion.getPuntuacionProducto());
            dto.setComentario(valoracion.getComentario());
            if (valoracion.getUsers() != null) {
                dto.setUserId(valoracion.getUsers().getId());
            }
            if (valoracion.getPedido() != null) {
                dto.setPedidoId(valoracion.getPedido().getId());
            }
            if (valoracion.getPrenda() != null) {
                dto.setPrendaId(valoracion.getPrenda().getId());
            }
            return dto;
        } else {
            throw new EntityNotFoundException("Valoracion not found with id: " + id);
        }
    }

    private ValoracionDTO convertToDTO(Valoracion valoracion) {
        return modelMapper.map(valoracion, ValoracionDTO.class);
    }
}
