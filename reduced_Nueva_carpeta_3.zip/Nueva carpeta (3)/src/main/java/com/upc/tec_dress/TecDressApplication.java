package com.upc.tec_dress;

import com.upc.tec_dress.entities.*;
import com.upc.tec_dress.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@SpringBootApplication
public class TecDressApplication {

    public static void main(String[] args) {
        SpringApplication.run(TecDressApplication.class, args);
    }

    @Bean
    public CommandLineRunner mappingDemo(
            AuthorityRepository authorityRepository,
            UserRepository userRepository,
            CompañiaEntregaRepository compañiaEntregaRepository,
            MetodoPagoRepository metodoPagoRepository,
            PedidoRepository pedidoRepository,
            PrendaRepository prendaRepository,
            ValoracionRepository valoracionRepository
    ) {
        return args -> {
            // Crear autoridades
            if (authorityRepository.findByName(AuthorityName.ROLE_ADMIN) == null) {
                authorityRepository.save(new Authority(AuthorityName.ROLE_ADMIN));
            }
            if (authorityRepository.findByName(AuthorityName.ROLE_CLIENTE) == null) {
                authorityRepository.save(new Authority(AuthorityName.ROLE_CLIENTE));
            }
            if (authorityRepository.findByName(AuthorityName.READ) == null) {
                authorityRepository.save(new Authority(AuthorityName.READ));
            }
            if (authorityRepository.findByName(AuthorityName.WRITE) == null) {
                authorityRepository.save(new Authority(AuthorityName.WRITE));
            }

            // Crear usuarios
            if (userRepository.findByUserName("gmorip") == null) {
                userRepository.save(
                            new User("gmorip", new BCryptPasswordEncoder().encode("UPC2023!"), true,
                                List.of(
                                        authorityRepository.findByName(AuthorityName.ROLE_ADMIN),
                                        authorityRepository.findByName(AuthorityName.WRITE)
                                ), "Geronima", "Ripeta",
                                Date.from(LocalDate.of(2002, 5, 9).atStartOfDay(ZoneId.systemDefault()).toInstant()),
                                "F", "geronima@example.com", "Direccion 1", 42)
                );
            }

            if (userRepository.findByUserName("crevilla") == null) {
                userRepository.save(
                        new User("crevilla", new BCryptPasswordEncoder().encode("DISEÑOPERU18!"), true,
                                List.of(
                                        authorityRepository.findByName(AuthorityName.ROLE_CLIENTE),
                                        authorityRepository.findByName(AuthorityName.READ)
                                ), "Crecia", "Lopez",
                                Date.from(LocalDate.of(2003, 11, 10).atStartOfDay(ZoneId.systemDefault()).toInstant()),
                                "Femenino", "crecia@example.com", "Direccion 2", 36)
                );
            }

            // Crear compañías de entrega
            if (!compañiaEntregaRepository.existsById(1)) {
                compañiaEntregaRepository.save(new CompaniaEntrega(1, "DHL", "Aereo", "20.50", "Av. Siempre Viva 123"));
            }
            if (!compañiaEntregaRepository.existsById(2)) {
                compañiaEntregaRepository.save(new CompaniaEntrega(2, "FedEx", "Terrestre", "15.00", "Calle Falsa 456"));
            }

            // Crear métodos de pago
            if (!metodoPagoRepository.existsById(1)) {
                metodoPagoRepository.save(new MetodoPago(1, "Credito", 12345678, LocalDate.of(2024, 12, 31), 123));
            }
            if (!metodoPagoRepository.existsById(2)) {
                metodoPagoRepository.save(new MetodoPago(2, "Debito", 98765432, LocalDate.of(2025, 11, 30), 456));
            }

            // Crear pedidos
            if (!pedidoRepository.existsById(1)) {
                pedidoRepository.save(new Pedido(1, 5, LocalDate.now(), LocalDate.now().plusDays(7), "Procesando", 120.00,
                        userRepository.findByUserName("gmorip"),
                        compañiaEntregaRepository.findById(1).orElse(null),
                        metodoPagoRepository.findById(1).orElse(null), null));
            }

            if (!pedidoRepository.existsById(2)) {
                pedidoRepository.save(new Pedido(2, 3, LocalDate.now(), LocalDate.now().plusDays(5), "Enviado", 75.00,
                        userRepository.findByUserName("crevilla"),
                        compañiaEntregaRepository.findById(2).orElse(null),
                        metodoPagoRepository.findById(2).orElse(null), null));
            }

            // Crear prendas
            if (!prendaRepository.existsById(1)) {
                prendaRepository.save(new Prenda(1, "Camiseta", "Rojo", 42, "Algodon", 25.00, 10, null));
            }
            if (!prendaRepository.existsById(2)) {
                prendaRepository.save(new Prenda(2, "Pantalón", "Azul", 38, "Jeans", 45.00, 5, null));
            }

            // Crear valoraciones
            if (!valoracionRepository.existsById(1)) {
                valoracionRepository.save(new Valoracion(1, 5, "Excelente calidad",
                        userRepository.findByUserName("crevilla"),
                        pedidoRepository.findById(1).orElse(null),
                        prendaRepository.findById(1).orElse(null)));
            }

            if (!valoracionRepository.existsById(2)) {
                valoracionRepository.save(new Valoracion(2, 4, "Muy bueno",
                        userRepository.findByUserName("gmorip"),
                        pedidoRepository.findById(2).orElse(null),
                        prendaRepository.findById(2).orElse(null)));
            }
        };
    }
}
