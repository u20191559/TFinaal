package com.upc.tec_dress.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompaniaEntregaDTO {
    private Integer idCompaniaEntrega;
    private String nCompaniaEntrega;
    private String metodoEnvio;
    private String costoEnvio;
    private String direccionCliente;
}
