package com.upc.tec_dress.dtos;

import javax.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PedidoDTO {
    private Integer id;
    private Integer cantidadPedido;
    private LocalDate fPedido;
    private LocalDate fEntrega;
    private String status;
    private Double precioTotal;
    private Long userId;
    private Integer companiaEntregaId;
    private Integer MetodoPagoId;
}
