package com.upc.tec_dress.dtos;

import javax.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ValoracionDTO {
    private Integer id;
    private Integer puntuacionProducto;
    private String comentario;
    private Long userId;
    private Integer pedidoId;
    private Integer prendaId;
}
