package com.upc.tec_dress.entities;

public enum AuthorityName {
    READ,
    WRITE,
    ROLE_ADMIN,
    ROLE_CLIENTE,
}
