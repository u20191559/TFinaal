package com.upc.tec_dress.entities;

import javax.persistence.*;

import lombok.*;

@Entity
@Table(name = "compania_entrega")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompaniaEntrega {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_CompaniaEntrega")
    private Integer idCompaniaEntrega;

    @Column(name = "n_CompaniaEntrega", nullable = false, length = 50)
    private String nCompaniaEntrega;

    @Column(name = "metodo_envio", nullable = false, length = 50)
    private String metodoEnvio;

    @Column(name = "costo_envio", nullable = false, length = 50)
    private String costoEnvio;

    @Column(name = "direccion_cliente", nullable = false, length = 100)
    private String direccionCliente;
}
