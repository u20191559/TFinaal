package com.upc.tec_dress.entities;

import javax.persistence.*;

import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "metodo_pago")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MetodoPago {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_metodopago")
    private Integer id;

    @Column(name = "tipo_pago", nullable = false, length = 10)
    private String tipoPago;

    @Column(name = "targeta_credito", nullable = false)
    private Integer targetaCredito;

    @Column(name = "f_vencimiento", nullable = false)
    private LocalDate fVencimiento;

    @Column(name = "codigo_seguridad", nullable = false)
    private Integer codigoSeguridad;
}