package com.upc.tec_dress.entities;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "pedido")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pedido", nullable = false)
    private Integer id;

    @Column(name = "cantidad_pedido", nullable = false)
    private Integer cantidadPedido;

    @Column(name = "f_pedido", nullable = false)
    private LocalDate fPedido;

    @Column(name = "f_entrega", nullable = false)
    private LocalDate fEntrega;

    @Column(name = "status", nullable = false, length = 50)
    private String status;

    @Column(name = "precio_total", nullable = false)
    private Double precioTotal; //corregir ojito
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User users;

    @ManyToOne
    @JoinColumn(name = "compania_entrega_id")
    private CompaniaEntrega companiaEntrega;

    @ManyToOne
    @JoinColumn(name = "metodo_pago_id")
    private MetodoPago metodoPago;

    @JsonIgnore
    @OneToMany(mappedBy = "pedido")
    private List<Valoracion> valoraciones;
}