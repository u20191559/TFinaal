package com.upc.tec_dress.entities;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "prenda")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Prenda {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_prenda")
    private Integer id;

    @Column(name = "t_prenda", nullable = false, length = 15)
    private String tPrenda;

    @Column(name = "color", nullable = false, length = 15)
    private String color;

    @Column(name = "talla", nullable = false)
    private Integer talla;

    @Column(name = "material", nullable = false, length = 20)
    private String material;

    @Column(name = "precio", nullable = false)
    private Double precio;

    @Column(name = "stock", nullable = false)
    private Integer stock;

    @OneToMany(mappedBy = "prenda")
    private List<Valoracion> valoraciones;
}