package com.upc.tec_dress.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.upc.tec_dress.entities.Authority;
import com.upc.tec_dress.entities.Pedido;
import com.upc.tec_dress.entities.Valoracion;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userName;
    private String password;

    private String firstName;

    private String lastName;

    private Date birthdate;
    private boolean enabled;
    private String genero;
    private String email;
    private String direccion;
    private Integer talla;

    @JsonIgnore
    @OneToMany(mappedBy = "users")
    private List<Pedido> pedidos;

    @JsonIgnore
    @OneToMany(mappedBy = "users")
    private List<Valoracion> valoraciones;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "users_authorities",
            joinColumns = {
                    @JoinColumn(
                            name="user_id",
                            referencedColumnName = "id",
                            nullable = false
                    )
            },
            inverseJoinColumns = {
                    @JoinColumn(
                            name = "authority_id",
                            referencedColumnName = "id",
                            nullable = false
                    )
            }
    )
    private List<Authority> authorities;

    public User(String userName, String password, boolean enabled, List<Authority> authorities, String firstName, String lastName, Date birthdate, String genero, String email, String direccion, Integer talla) {
        this.userName = userName;
        this.password = password;
        this.enabled = enabled;
        this.authorities = authorities;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthdate = birthdate;
        this.genero = genero;
        this.email = email;
        this.direccion = direccion;
        this.talla = talla;
    }
}
