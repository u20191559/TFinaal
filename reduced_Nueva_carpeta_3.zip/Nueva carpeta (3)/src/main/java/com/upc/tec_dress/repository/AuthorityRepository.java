package com.upc.tec_dress.repository;


import com.upc.tec_dress.entities.Authority;
import com.upc.tec_dress.entities.AuthorityName;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorityRepository extends JpaRepository<Authority,Long> {
    public Authority findByName(AuthorityName name);
}
