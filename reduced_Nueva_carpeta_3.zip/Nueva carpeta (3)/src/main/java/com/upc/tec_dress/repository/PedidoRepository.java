package com.upc.tec_dress.repository;

import com.upc.tec_dress.entities.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido,Integer> {
    @Query("SELECT SUM(precioTotal) FROM Pedido")
    Double getBalanceGanancias();

    @Modifying
    @Query("UPDATE Pedido p SET p.users.id = :userId, p.companiaEntrega.idCompaniaEntrega = :companiaEntregaId, p.metodoPago.id = :metodoPagoId WHERE p.id = :pedidoId")
    void assignDataToPedido(@Param("userId") Integer userId, @Param("companiaEntregaId") Integer companiaEntregaId, @Param("metodoPagoId") Integer metodoPagoId, @Param("pedidoId") Integer pedidoId);
}
