package com.upc.tec_dress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TecDressApplicationTests {

    @Test
    void contextLoads() {
    }

}
